// Package topology combines asset/flow/tag data from three
// independent engines into a single node+edge graph (Graph, model.go)
// for network visualization, and provides the OT/IT classification
// (Classify) that both the graph and the plain /assets endpoint use
// to mark a device as OT. Computed fresh on every call from each
// engine's current snapshot — see Build's doc comment for why this
// isn't its own stateful engine.
package topology

import (
	"net"

	"github.com/zabojnikvlado/otlens_linux/internal/asset"
	"github.com/zabojnikvlado/otlens_linux/internal/flow"
	"github.com/zabojnikvlado/otlens_linux/internal/oui"
	"github.com/zabojnikvlado/otlens_linux/internal/store"
)

// isPrivateIP reports whether ip is an RFC 1918 / RFC 4193 private
// address (or loopback). The Topology map only ever shows the
// monitored network, not the wider internet — an internet-facing flow
// endpoint has no stable identity here anyway (rotating CDN/cloud IPs
// would otherwise make the ledger in internal/central/topology_edges.go
// grow without bound, the same class of problem alert history had
// before delta-sync). An internal asset genuinely talking externally is
// still worth surfacing — just as a detection alert, not a map node;
// see internal/detect's external-communication rule. Malformed/
// unparseable input is treated as not-private (fails safe).
func isPrivateIP(ip string) bool {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	return parsed.IsPrivate() || parsed.IsLoopback()
}

// Build combines the independently-tracked asset/flow/tag data into
// a single node+edge graph for visualization. This is deliberately
// computed on demand from each engine's current snapshot rather than
// maintained as its own stateful engine — assets/flows/tags already
// are the source of truth and are cheap to re-aggregate on each API
// request; keeping a fourth copy of this data in sync would be
// needless complexity for what is, today, a read-only view.
//
// modbusPort/s7Port must be whatever the ics.Engine was actually
// configured with (see ics.Engine.ModbusPort/S7Port) — passed in
// rather than referencing ics.PortModbus/PortS7Comm directly, so
// that changing the configured port doesn't leave this OT
// classification silently checking the old default.
//
// honeypotThreshold is config.Deception.HoneypotThreshold, passed
// straight through to Graph.HoneypotThreshold — the frontend uses it
// to decide which nodes count as a honeypot (Node.Score >= this) for
// coloring. Edge.FromHoneypot itself comes from flow.Flow.
// HoneypotInitiated directly (computed upstream, per-packet, in
// flow.Engine — see that field's doc comment for why this can't be
// derived here from Node.Score the way it first looked like it
// could).
func Build(
	assets []*asset.Asset,
	flows []*flow.Flow,
	tags []*store.Tag,
	modbusPort uint16,
	s7Port uint16,
	honeypotThreshold int,
) Graph {

	isOT, protocols := Classify(tags)

	nodes := make([]Node, 0, len(assets))
	// Used below to orient FromHoneypot edges correctly — see the edges
	// loop's comment.
	scoreByIP := make(map[string]int, len(assets))

	for _, a := range assets {

		scoreByIP[a.IP] = a.Score

		nodes = append(
			nodes,
			Node{
				ID: a.MAC,

				IP:       a.IP,
				MAC:      a.MAC,
				Hostname: a.Hostname,
				Vendor:   oui.Lookup(a.MAC),

				IsOT:      isOT[a.IP],
				Protocols: protocols[a.IP],

				Confirmed: a.Confirmed,
				Score:     a.Score,
				VLANID:    a.VLANID,

				FirstSeen: a.FirstSeen,
				LastSeen:  a.LastSeen,

				PacketCount: a.PacketCount,
			},
		)

	}

	edges := make([]Edge, 0, len(flows))

	for _, f := range flows {

		srcIP, dstIP := f.SrcIP, f.DstIP
		// f.SrcIP/f.DstIP reflect whichever direction happened to create
		// the flow record first (see flow.Flow's doc comment) — NOT
		// necessarily the honeypot's side, even when HoneypotInitiated is
		// true. A flow first created by something probing the honeypot,
		// which only later (same bidirectional record) saw the honeypot
		// itself send something back, would otherwise leave the arrow on
		// the Topology tab pointing the wrong way — into the honeypot
		// instead of out of it. Swap so SrcIP is always the honeypot's IP
		// when this flag is set, matching what "lateral movement"
		// actually means: traffic leaving the honeypot.
		if f.HoneypotInitiated && scoreByIP[srcIP] < honeypotThreshold && scoreByIP[dstIP] >= honeypotThreshold {
			srcIP, dstIP = dstIP, srcIP
		}

		// Analysis-derived flows are exempt from the private-IP-only
		// restriction below — see Prune()'s identical FromAnalysis
		// exemption in internal/flow/engine.go for the same underlying
		// reasoning. That filter exists to stop *continuous live
		// capture* from growing the topology ledger without bound as
		// it accumulates internet-facing noise over time; a PCAP
		// analysis is a one-shot, human-initiated investigation of a
		// specific bounded file, not an ongoing growth risk, and seeing
		// what a device talked to externally is very often the whole
		// point of analyzing a suspicious capture (e.g. investigating a
		// suspected malware/C2 sample).
		if !f.FromAnalysis && (!isPrivateIP(srcIP) || !isPrivateIP(dstIP)) {
			continue
		}

		edges = append(
			edges,
			Edge{
				ID: f.ID,

				SrcIP: srcIP,
				DstIP: dstIP,

				Protocol: f.Protocol,
				SrcPort:  f.SrcPort, DstPort: f.DstPort,
				InitiatorIP: f.InitiatorIP, ResponderIP: f.ResponderIP,
				InitiatorPort: f.InitiatorPort, ResponderPort: f.ResponderPort,
				PacketsAToB: f.PacketsAToB, PacketsBToA: f.PacketsBToA,
				BytesAToB: f.BytesAToB, BytesBToA: f.BytesBToA,

				IsOT: isICSPort(f.SrcPort, modbusPort, s7Port) || isICSPort(f.DstPort, modbusPort, s7Port),

				// f.HoneypotInitiated, not scoreByIP[f.SrcIP] — a flow
				// folds both directions of a conversation together,
				// so f.SrcIP only reflects whichever packet happened
				// to create the record first, not "did the honeypot
				// ever send anything on this pair." See
				// flow.Flow.HoneypotInitiated's doc comment.
				FromHoneypot: f.HoneypotInitiated,
				VLANID:       f.VLANID,

				Packets: f.Packets,
				Bytes:   f.Bytes,

				FirstSeen: f.FirstSeen,
				LastSeen:  f.LastSeen,
			},
		)

	}

	return Graph{
		Nodes: nodes,
		Edges: edges,

		HoneypotThreshold: honeypotThreshold,
	}
}

// Classify derives, per device IP, whether it has been observed
// speaking a recognized OT/ICS protocol and which ones. Exported
// separately from Build so other views (e.g. the /assets endpoint)
// can enrich their own response with the same classification without
// needing a full topology graph.
func Classify(tags []*store.Tag) (isOT map[string]bool, protocols map[string][]string) {

	isOT = make(map[string]bool)

	protocolSet := make(map[string]map[string]bool)

	for _, t := range tags {

		isOT[t.DeviceIP] = true

		if protocolSet[t.DeviceIP] == nil {
			protocolSet[t.DeviceIP] = make(map[string]bool)
		}

		protocolSet[t.DeviceIP][t.Protocol] = true
	}

	protocols = make(map[string][]string)

	for ip, set := range protocolSet {

		list := make([]string, 0, len(set))

		for protocol := range set {
			list = append(list, protocol)
		}

		protocols[ip] = list
	}

	return isOT, protocols
}

// isICSPort reports whether a port is a configured OT/ICS protocol
// port, used to flag an Edge as OT traffic even in cases where the
// ics parser itself didn't produce a decoded Message for it (e.g.
// non-standard payload on the standard port).
func isICSPort(port, modbusPort, s7Port uint16) bool {

	return port == modbusPort || port == s7Port
}
