package central

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/zabojnikvlado/otlens_linux/internal/management"
	"github.com/zabojnikvlado/otlens_linux/internal/topology"

	"errors"
)

type Repository struct {
	db                *sql.DB
	siemAlertsEnabled bool
}

func OpenPostgres(dsn string) (*Repository, error) {
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return nil, fmt.Errorf("open postgres: %w", err)
	}
	if err := db.Ping(); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}
	// Bootstrap the complete Central schema in dependency order. The binary must
	// be able to start against a newly-created, empty PostgreSQL database without
	// requiring the operator to run db/central_phase3.sql manually first.
	schema := `
CREATE TABLE IF NOT EXISTS schema_migrations (
 version BIGINT PRIMARY KEY,
 name TEXT NOT NULL,
 applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS sites (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS sensors (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL DEFAULT '',
 site_id TEXT REFERENCES sites(id),
 status TEXT NOT NULL DEFAULT 'offline',
 version TEXT NOT NULL DEFAULT '',
 hostname TEXT NOT NULL DEFAULT '',
 certificate_fingerprint TEXT,
 auth_token_hash TEXT NOT NULL DEFAULT '',
 auth_token_rotated_at TIMESTAMPTZ,
 go_version TEXT NOT NULL DEFAULT '',
 libpcap_version TEXT NOT NULL DEFAULT '',
 gopacket_version TEXT NOT NULL DEFAULT '',
 capture_backend TEXT NOT NULL DEFAULT '',
 capture_interface TEXT NOT NULL DEFAULT '',
 capture_snaplen INTEGER NOT NULL DEFAULT 0,
 capture_promiscuous BOOLEAN NOT NULL DEFAULT FALSE,
 last_heartbeat_at TIMESTAMPTZ,
 last_sync_attempt_at TIMESTAMPTZ,
 last_sync_success_at TIMESTAMPTZ,
 last_data_received_at TIMESTAMPTZ,
 sync_status TEXT NOT NULL DEFAULT 'unknown',
 pending_records BIGINT NOT NULL DEFAULT 0,
 sync_failures INTEGER NOT NULL DEFAULT 0,
 last_sync_error TEXT NOT NULL DEFAULT '',
 sync_sequence BIGINT NOT NULL DEFAULT 0,
 last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS rule_sets (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 version BIGINT NOT NULL DEFAULT 1,
 rules JSONB NOT NULL DEFAULT '[]'::jsonb,
 dns_observations JSONB NOT NULL DEFAULT '[]'::jsonb,
 smb_observations JSONB NOT NULL DEFAULT '[]'::jsonb,
 batch_id TEXT NOT NULL DEFAULT '',
 sequence BIGINT NOT NULL DEFAULT 0,
 checksum TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS sensor_rule_sets (
 sensor_id TEXT PRIMARY KEY REFERENCES sensors(id) ON DELETE CASCADE,
 rule_set_id TEXT NOT NULL REFERENCES rule_sets(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS sensor_telemetry (
 sensor_id TEXT PRIMARY KEY REFERENCES sensors(id) ON DELETE CASCADE,
 captured_at TIMESTAMPTZ NOT NULL,
 topology JSONB NOT NULL DEFAULT '{"Nodes":[],"Edges":[],"HoneypotThreshold":10}'::jsonb,
 tags JSONB NOT NULL DEFAULT '[]'::jsonb,
 tag_changes JSONB NOT NULL DEFAULT '[]'::jsonb,
 tag_events JSONB NOT NULL DEFAULT '[]'::jsonb,
 alerts JSONB NOT NULL DEFAULT '[]'::jsonb,
 baseline JSONB NOT NULL DEFAULT '{}'::jsonb,
 rules JSONB NOT NULL DEFAULT '[]'::jsonb,
 batch_id TEXT NOT NULL DEFAULT '',
 sequence BIGINT NOT NULL DEFAULT 0,
 checksum TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS go_version TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS libpcap_version TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS gopacket_version TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS capture_backend TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS capture_interface TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS capture_snaplen INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS capture_promiscuous BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS last_heartbeat_at TIMESTAMPTZ;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS last_sync_attempt_at TIMESTAMPTZ;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS last_sync_success_at TIMESTAMPTZ;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS last_data_received_at TIMESTAMPTZ;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS sync_status TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS pending_records BIGINT NOT NULL DEFAULT 0;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS sync_failures INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS last_sync_error TEXT NOT NULL DEFAULT '';
ALTER TABLE sensors ADD COLUMN IF NOT EXISTS sync_sequence BIGINT NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS sensor_metrics (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 uptime_seconds BIGINT NOT NULL DEFAULT 0,
 health JSONB NOT NULL DEFAULT '{}'::jsonb,
 metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
 versions JSONB NOT NULL DEFAULT '{}'::jsonb,
 capture JSONB NOT NULL DEFAULT '{}'::jsonb,
 sync JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_sensor_metrics_sensor_time ON sensor_metrics(sensor_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS sensors_last_seen_idx ON sensors(last_seen);
CREATE INDEX IF NOT EXISTS sensor_telemetry_captured_at_idx ON sensor_telemetry(captured_at);
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS tag_changes JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS tag_events JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS alerts JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS baseline JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS rules JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS dns_observations JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS smb_observations JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS batch_id TEXT NOT NULL DEFAULT '';
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS sequence BIGINT NOT NULL DEFAULT 0;
ALTER TABLE sensor_telemetry ADD COLUMN IF NOT EXISTS checksum TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS reconnaissance_credentials (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 type TEXT NOT NULL,
 username TEXT NOT NULL DEFAULT '',
 encrypted_secret BYTEA NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS reconnaissance_campaigns (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 profile TEXT NOT NULL DEFAULT 'safe-discovery',
 targets JSONB NOT NULL DEFAULT '[]'::jsonb,
 policy JSONB NOT NULL DEFAULT '{}'::jsonb,
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 last_run_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS reconnaissance_jobs (
 id TEXT PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 profile TEXT NOT NULL DEFAULT 'safe-discovery',
 targets JSONB NOT NULL DEFAULT '[]'::jsonb,
 policy JSONB NOT NULL DEFAULT '{}'::jsonb,
 status TEXT NOT NULL DEFAULT 'queued',
 error TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 started_at TIMESTAMPTZ,
 completed_at TIMESTAMPTZ
);
ALTER TABLE reconnaissance_jobs ADD COLUMN IF NOT EXISTS campaign_id TEXT REFERENCES reconnaissance_campaigns(id) ON DELETE SET NULL;
CREATE TABLE IF NOT EXISTS asset_recon_history (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 ip TEXT NOT NULL,
 job_id TEXT NOT NULL REFERENCES reconnaissance_jobs(id) ON DELETE CASCADE,
 result JSONB NOT NULL,
 changes JSONB NOT NULL DEFAULT '[]'::jsonb,
 observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_asset_recon_history_asset ON asset_recon_history(sensor_id,ip,observed_at DESC);
CREATE TABLE IF NOT EXISTS asset_recon_profile (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 ip TEXT NOT NULL,
 hostname TEXT NOT NULL DEFAULT '',
 vendor TEXT NOT NULL DEFAULT '',
 operating_system TEXT NOT NULL DEFAULT '',
 model TEXT NOT NULL DEFAULT '',
 firmware TEXT NOT NULL DEFAULT '',
 serial TEXT NOT NULL DEFAULT '',
 ot_identity JSONB NOT NULL DEFAULT '{}'::jsonb,
 services JSONB NOT NULL DEFAULT '[]'::jsonb,
 evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
 last_profiled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(sensor_id,ip)
);
ALTER TABLE asset_recon_profile ADD COLUMN IF NOT EXISTS model TEXT NOT NULL DEFAULT '';
ALTER TABLE asset_recon_profile ADD COLUMN IF NOT EXISTS firmware TEXT NOT NULL DEFAULT '';
ALTER TABLE asset_recon_profile ADD COLUMN IF NOT EXISTS serial TEXT NOT NULL DEFAULT '';
ALTER TABLE asset_recon_profile ADD COLUMN IF NOT EXISTS ot_identity JSONB NOT NULL DEFAULT '{}'::jsonb;
CREATE TABLE IF NOT EXISTS reconnaissance_results (
 id BIGSERIAL PRIMARY KEY,
 job_id TEXT NOT NULL REFERENCES reconnaissance_jobs(id) ON DELETE CASCADE,
 target TEXT NOT NULL,
 result JSONB NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_recon_jobs_created ON reconnaissance_jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_recon_results_job ON reconnaissance_results(job_id);
CREATE TABLE IF NOT EXISTS sensor_commands (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 command_type TEXT NOT NULL,
 target TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 delivered_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_sensor_commands_pending ON sensor_commands(sensor_id,id) WHERE delivered_at IS NULL;
CREATE TABLE IF NOT EXISTS siem_outbox (
 id BIGSERIAL PRIMARY KEY,
 event_key TEXT NOT NULL UNIQUE,
 kind TEXT NOT NULL,
 payload JSONB NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 attempts INTEGER NOT NULL DEFAULT 0,
 last_error TEXT NOT NULL DEFAULT '',
 delivered_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_siem_outbox_pending ON siem_outbox(next_attempt_at,id) WHERE delivered_at IS NULL;
CREATE TABLE IF NOT EXISTS analysis_jobs (
 id TEXT PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 filename TEXT NOT NULL,
 stored_path TEXT NOT NULL,
 sha256 TEXT NOT NULL,
 size_bytes BIGINT NOT NULL,
 status TEXT NOT NULL DEFAULT 'queued',
 protocols JSONB NOT NULL DEFAULT '["auto"]'::jsonb,
 packets INTEGER NOT NULL DEFAULT 0,
 assets_discovered INTEGER NOT NULL DEFAULT 0,
 flows_discovered INTEGER NOT NULL DEFAULT 0,
 tags_discovered INTEGER NOT NULL DEFAULT 0,
 alerts_generated INTEGER NOT NULL DEFAULT 0,
 result JSONB NOT NULL DEFAULT '{}'::jsonb,
 error TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 started_at TIMESTAMPTZ,
 completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_analysis_jobs_sensor_status ON analysis_jobs(sensor_id,status,created_at);
CREATE TABLE IF NOT EXISTS system_backups (
 id TEXT PRIMARY KEY,
 kind TEXT NOT NULL,
 name TEXT NOT NULL,
 payload JSONB NOT NULL,
 size_bytes BIGINT NOT NULL DEFAULT 0,
 sha256 TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS roles (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 built_in BOOLEAN NOT NULL DEFAULT FALSE,
 permissions JSONB NOT NULL DEFAULT '{}'::jsonb,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role_id TEXT NOT NULL REFERENCES roles(id),
 display_name TEXT NOT NULL DEFAULT '',
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
 password_expires_at TIMESTAMPTZ,
 password_validity_days INTEGER,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 last_login_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 expires_at TIMESTAMPTZ NOT NULL,
 last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 user_agent TEXT NOT NULL DEFAULT '',
 ip TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_validity_days INTEGER;

-- Sensors prune flows that have gone quiet for a while (see
-- internal/flow/engine.go's Prune) to bound their own SQLite growth —
-- that's correct and necessary on the sensor, but it means a connection
-- that only happened once can disappear from a later telemetry sync's
-- topology blob even though it genuinely occurred. This table is Central's
-- own durable, ever-growing record of every asset pair a sensor has ever
-- reported: PutTelemetry upserts into it on every sync (see
-- upsertTopologyEdges), and the /topology handler reads from here instead
-- of the live per-sensor snapshot, so a connection drawn once stays on the
-- map even after the sensor's own copy of it has aged out.
CREATE TABLE IF NOT EXISTS dns_observations (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 observed_at TIMESTAMPTZ NOT NULL,
 client_ip TEXT NOT NULL DEFAULT '',
 server_ip TEXT NOT NULL DEFAULT '',
 query_name TEXT NOT NULL,
 query_type INTEGER NOT NULL DEFAULT 0,
 response_code INTEGER NOT NULL DEFAULT 0,
 is_response BOOLEAN NOT NULL DEFAULT FALSE,
 answers JSONB NOT NULL DEFAULT '[]'::jsonb,
 cnames JSONB NOT NULL DEFAULT '[]'::jsonb,
 ttl BIGINT NOT NULL DEFAULT 0,
 UNIQUE(sensor_id,observed_at,client_ip,query_name,is_response)
);
CREATE INDEX IF NOT EXISTS idx_dns_observations_lookup ON dns_observations(sensor_id,observed_at,query_name);
CREATE INDEX IF NOT EXISTS idx_dns_observations_client ON dns_observations(sensor_id,client_ip,observed_at);

CREATE TABLE IF NOT EXISTS smb_observations (
 id BIGSERIAL PRIMARY KEY, sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 observed_at TIMESTAMPTZ NOT NULL, client_ip TEXT NOT NULL DEFAULT '', server_ip TEXT NOT NULL DEFAULT '',
 client_port INTEGER NOT NULL DEFAULT 0, server_port INTEGER NOT NULL DEFAULT 445, command TEXT NOT NULL DEFAULT '',
 message_id NUMERIC(20,0) NOT NULL DEFAULT 0, session_id NUMERIC(20,0) NOT NULL DEFAULT 0, tree_id BIGINT NOT NULL DEFAULT 0,
 share_name TEXT NOT NULL DEFAULT '', file_name TEXT NOT NULL DEFAULT '', named_pipe TEXT NOT NULL DEFAULT '', direction TEXT NOT NULL DEFAULT '',
 bytes BIGINT NOT NULL DEFAULT 0, status BIGINT NOT NULL DEFAULT 0, is_response BOOLEAN NOT NULL DEFAULT FALSE,
 is_admin_share BOOLEAN NOT NULL DEFAULT FALSE, is_executable BOOLEAN NOT NULL DEFAULT FALSE, is_script BOOLEAN NOT NULL DEFAULT FALSE, is_encrypted BOOLEAN NOT NULL DEFAULT FALSE,
 UNIQUE(sensor_id,observed_at,client_ip,server_ip,message_id,command,is_response)
);
CREATE INDEX IF NOT EXISTS idx_smb_observations_lookup ON smb_observations(sensor_id,observed_at,client_ip,server_ip);
CREATE INDEX IF NOT EXISTS idx_smb_observations_artifact ON smb_observations(sensor_id,share_name,file_name,observed_at);
CREATE TABLE IF NOT EXISTS flow_counters (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 flow_id TEXT NOT NULL,
 packets BIGINT NOT NULL DEFAULT 0,
 bytes BIGINT NOT NULL DEFAULT 0,
 packets_a_to_b BIGINT NOT NULL DEFAULT 0,
 packets_b_to_a BIGINT NOT NULL DEFAULT 0,
 bytes_a_to_b BIGINT NOT NULL DEFAULT 0,
 bytes_b_to_a BIGINT NOT NULL DEFAULT 0,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(sensor_id,flow_id)
);
CREATE TABLE IF NOT EXISTS flow_observations (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 flow_id TEXT NOT NULL,
 bucket_start TIMESTAMPTZ NOT NULL,
 bucket_end TIMESTAMPTZ NOT NULL,
 src_ip TEXT NOT NULL,
 dst_ip TEXT NOT NULL,
 src_port INTEGER NOT NULL DEFAULT 0,
 dst_port INTEGER NOT NULL DEFAULT 0,
 protocol TEXT NOT NULL DEFAULT '',
 initiator_ip TEXT NOT NULL DEFAULT '',
 responder_ip TEXT NOT NULL DEFAULT '',
 initiator_port INTEGER NOT NULL DEFAULT 0,
 responder_port INTEGER NOT NULL DEFAULT 0,
 packets BIGINT NOT NULL DEFAULT 0,
 bytes BIGINT NOT NULL DEFAULT 0,
 packets_a_to_b BIGINT NOT NULL DEFAULT 0,
 packets_b_to_a BIGINT NOT NULL DEFAULT 0,
 bytes_a_to_b BIGINT NOT NULL DEFAULT 0,
 bytes_b_to_a BIGINT NOT NULL DEFAULT 0,
 vlan_id INTEGER NOT NULL DEFAULT 0,
 is_ot BOOLEAN NOT NULL DEFAULT FALSE,
 UNIQUE(sensor_id,flow_id,bucket_start)
);
CREATE INDEX IF NOT EXISTS idx_flow_observations_contact ON flow_observations(sensor_id,bucket_start,src_ip,dst_ip);
CREATE TABLE IF NOT EXISTS asset_security_status (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 asset_ip TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('clean','suspected','infected','contained','recovered')),
 reason TEXT NOT NULL DEFAULT '',
 source TEXT NOT NULL DEFAULT 'manual',
 detected_at TIMESTAMPTZ,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_by TEXT NOT NULL DEFAULT '',
 PRIMARY KEY(sensor_id,asset_ip)
);
CREATE TABLE IF NOT EXISTS malware_incidents (
 id BIGSERIAL PRIMARY KEY,
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 initial_asset_ip TEXT NOT NULL,
 title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open',
 severity TEXT NOT NULL DEFAULT 'critical',
 lookback_hours INTEGER NOT NULL DEFAULT 24,
 max_hops INTEGER NOT NULL DEFAULT 2,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS asset_exposures (
 incident_id BIGINT NOT NULL REFERENCES malware_incidents(id) ON DELETE CASCADE,
 exposed_asset_ip TEXT NOT NULL,
 parent_asset_ip TEXT NOT NULL DEFAULT '',
 hop_count INTEGER NOT NULL,
 exposure_score INTEGER NOT NULL,
 exposure_severity TEXT NOT NULL,
 reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
 first_contact TIMESTAMPTZ,
 last_contact TIMESTAMPTZ,
 protocols TEXT NOT NULL DEFAULT '',
 bytes BIGINT NOT NULL DEFAULT 0,
 packets BIGINT NOT NULL DEFAULT 0,
 PRIMARY KEY(incident_id,exposed_asset_ip)
);
DO $$
BEGIN
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='asset_exposures' AND column_name='score')
    AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='asset_exposures' AND column_name='exposure_score') THEN
  ALTER TABLE asset_exposures RENAME COLUMN score TO exposure_score;
 END IF;
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='asset_exposures' AND column_name='severity')
    AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='asset_exposures' AND column_name='exposure_severity') THEN
  ALTER TABLE asset_exposures RENAME COLUMN severity TO exposure_severity;
 END IF;
END $$;

CREATE TABLE IF NOT EXISTS topology_edges (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 pair_key TEXT NOT NULL,
 src_ip TEXT NOT NULL,
 dst_ip TEXT NOT NULL,
 protocols TEXT NOT NULL DEFAULT '',
 is_ot BOOLEAN NOT NULL DEFAULT FALSE,
 from_honeypot BOOLEAN NOT NULL DEFAULT FALSE,
 vlan_id INTEGER NOT NULL DEFAULT 0,
 packets BIGINT NOT NULL DEFAULT 0,
 bytes BIGINT NOT NULL DEFAULT 0,
 flow_count INTEGER NOT NULL DEFAULT 1,
 first_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (sensor_id, pair_key)
);
-- Companion to topology_edges, same reasoning: a sensor's live topology
-- snapshot only ever contains its *current* assets (subject to the same
-- persist.retention pruning as flows). Without this, an edge safely
-- recorded in topology_edges becomes undrawable the moment either
-- endpoint asset ages out of the live snapshot, since the frontend can
-- only place an edge between two nodes it actually has — exactly the
-- "the line was there, then it vanished" symptom this fixes. See
-- upsertTopologyNodes/ListTopologyNodes in internal/central/topology_edges.go.
CREATE TABLE IF NOT EXISTS topology_nodes (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 ip TEXT NOT NULL,
 mac TEXT NOT NULL DEFAULT '',
 hostname TEXT NOT NULL DEFAULT '',
 vendor TEXT NOT NULL DEFAULT '',
 is_ot BOOLEAN NOT NULL DEFAULT FALSE,
 protocols TEXT NOT NULL DEFAULT '',
 confirmed BOOLEAN NOT NULL DEFAULT TRUE,
 score INTEGER NOT NULL DEFAULT 1,
 vlan_id INTEGER NOT NULL DEFAULT 0,
 packet_count BIGINT NOT NULL DEFAULT 0,
 first_seen TIMESTAMPTZ NOT NULL,
 last_seen TIMESTAMPTZ NOT NULL,
 PRIMARY KEY (sensor_id, ip)
);
-- Durable, one-row-per-alert history, independent of sensor_telemetry.alerts
-- (which is a single JSONB array per sensor, wholesale-overwritten on every
-- sync — no per-alert timestamp to prune by). Upserted from that JSONB on
-- every PutTelemetry, same pattern as topology_edges/topology_nodes. This is
-- what database_retention.alerts_days actually prunes; it does not replace
-- the live Alerts tab, which still reads the current sensor_telemetry.alerts
-- snapshot.
CREATE TABLE IF NOT EXISTS alert_history (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 alert_key TEXT NOT NULL,
 type TEXT NOT NULL,
 severity TEXT NOT NULL,
 message TEXT NOT NULL,
 ip TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'new',
 approved_by TEXT NOT NULL DEFAULT '',
 approved_at TIMESTAMPTZ,
 count BIGINT NOT NULL DEFAULT 1,
 first_seen TIMESTAMPTZ NOT NULL,
 last_seen TIMESTAMPTZ NOT NULL,
 PRIMARY KEY (sensor_id, alert_key)
);
CREATE INDEX IF NOT EXISTS idx_alert_history_last_seen ON alert_history(last_seen);
ALTER TABLE alert_history ADD COLUMN IF NOT EXISTS count BIGINT NOT NULL DEFAULT 1;

-- Written unconditionally by auditMiddleware for every mutating
-- Management API request, independent of whether SIEM export is
-- configured — siem_outbox (a delivery queue whose rows are deleted once
-- delivered) was never a retained history and only existed at all when
-- SIEM was enabled. This is what the Audit tab reads and what
-- database_retention.audit_days prunes.
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGSERIAL PRIMARY KEY,
 actor TEXT NOT NULL DEFAULT '',
 action TEXT NOT NULL,
 method TEXT NOT NULL,
 path TEXT NOT NULL,
 status INTEGER NOT NULL,
 success BOOLEAN NOT NULL,
 source_ip TEXT NOT NULL DEFAULT '',
 sensor_id TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON audit_log(created_at);
-- One row per generated report (see internal/central/reports.go). Kept
-- regardless of whether email delivery is configured or succeeds — the
-- Reports tab reads this table directly, so a report is always viewable
-- even on a fully offline/air-gapped Central with no SMTP configured at
-- all.
CREATE TABLE IF NOT EXISTS report_history (
 id TEXT PRIMARY KEY,
 period_start TIMESTAMPTZ NOT NULL,
 period_end TIMESTAMPTZ NOT NULL,
 html TEXT NOT NULL,
 recipients TEXT NOT NULL DEFAULT '',
 email_sent BOOLEAN NOT NULL DEFAULT FALSE,
 email_error TEXT NOT NULL DEFAULT '',
 generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_report_history_generated_at ON report_history(generated_at);
-- Manual/imported category+name overrides for the Devices tab — see
-- internal/central/devices.go. Never touched by any sensor sync; this
-- is purely operator input (either one-by-one from the Devices tab, or
-- bulk via CSV import) and always wins over the automatic vendor-based
-- category guess for a given (sensor_id, mac).
CREATE TABLE IF NOT EXISTS asset_context (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 asset_ip TEXT NOT NULL,
 asset_role TEXT NOT NULL DEFAULT '',
 criticality TEXT NOT NULL DEFAULT '',
 zone TEXT NOT NULL DEFAULT '',
 purdue_override REAL,
 is_attack_path_entry BOOLEAN NOT NULL DEFAULT FALSE,
 is_attack_path_target BOOLEAN NOT NULL DEFAULT FALSE,
 updated_by TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(sensor_id,asset_ip)
);
CREATE INDEX IF NOT EXISTS idx_flow_observations_itot ON flow_observations(sensor_id,bucket_end,initiator_ip,responder_ip);
CREATE TABLE IF NOT EXISTS imported_tags (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 tag_key TEXT NOT NULL,
 tag JSONB NOT NULL DEFAULT '{}'::jsonb,
 imported_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 imported_by TEXT NOT NULL DEFAULT '',
 PRIMARY KEY(sensor_id, tag_key)
);
CREATE TABLE IF NOT EXISTS asset_overrides (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 mac TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT '',
 name TEXT NOT NULL DEFAULT '',
 updated_by TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (sensor_id, mac)
);
-- VLAN display name + assigned Purdue Model level, managed from the
-- Network Segmentation tab — see internal/central/segmentation.go. This
-- is Central's copy for naming/visualization; the sensor's own
-- detect.segmentation.vlanlevels (its config file) is what the live
-- segmentation_violation detection rule actually runs against — see
-- that tab's own notes on why the two aren't automatically the same
-- thing yet.
CREATE TABLE IF NOT EXISTS vlan_config (
 sensor_id TEXT NOT NULL REFERENCES sensors(id) ON DELETE CASCADE,
 vlan_id INTEGER NOT NULL,
 name TEXT NOT NULL DEFAULT '',
 purdue_level REAL,
 updated_by TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (sensor_id, vlan_id)
);
-- The one setting vlan_config doesn't cover (it's per-sensor, not
-- per-VLAN): how many Purdue levels apart two VLANs may communicate
-- before segmentation_violation fires. Kept here so pushSegmentationConfig
-- (internal/central/segmentation.go) has everything it needs to send the
-- sensor a complete "segmentation.config" command without also requiring
-- detect.segmentation.maxleveljump in that sensor's local config file.
CREATE TABLE IF NOT EXISTS segmentation_settings (
 sensor_id TEXT PRIMARY KEY REFERENCES sensors(id) ON DELETE CASCADE,
 max_level_jump REAL NOT NULL DEFAULT 1,
 updated_by TEXT NOT NULL DEFAULT '',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
`
	if _, err := db.Exec(schema); err != nil {
		db.Close()
		return nil, fmt.Errorf("ensure central database schema: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(1,'central bootstrap schema') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record central schema migration: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(2,'discovery campaigns and asset recon history') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record discovery campaign migration: %w", err)
	}
	if _, err := db.Exec(vulnerabilitySchema); err != nil {
		db.Close()
		return nil, fmt.Errorf("bootstrap vulnerability schema: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(3,'vulnerability finding lifecycle') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record vulnerability lifecycle migration: %w", err)
	}
	if _, err := db.Exec(threatIntelSchema); err != nil {
		db.Close()
		return nil, fmt.Errorf("ensure threat intelligence schema: %w", err)
	}
	if _, err := db.Exec(incidentManagementSchema); err != nil {
		db.Close()
		return nil, fmt.Errorf("ensure incident management schema: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(4,'incident management correlation and asset risk') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record incident management migration: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(5,'advanced correlation rules and MITRE mapping') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record advanced correlation migration: %w", err)
	}
	if _, err := db.Exec(`INSERT INTO schema_migrations(version,name) VALUES(6,'advanced contextual asset risk engine') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("record advanced asset risk migration: %w", err)
	}
	if _, err := db.Exec(`ALTER TABLE sensors ADD COLUMN IF NOT EXISTS auth_token_hash TEXT NOT NULL DEFAULT ''; ALTER TABLE sensors ADD COLUMN IF NOT EXISTS auth_token_rotated_at TIMESTAMPTZ; INSERT INTO schema_migrations(version,name) VALUES(7,'per-sensor authentication tokens and live RBAC') ON CONFLICT(version) DO NOTHING`); err != nil {
		db.Close()
		return nil, fmt.Errorf("apply sensor authentication migration: %w", err)
	}
	return &Repository{db: db}, nil
}
func (r *Repository) Close() error { return r.db.Close() }

func (r *Repository) ConfigureSIEM(alertsEnabled bool) {
	r.siemAlertsEnabled = alertsEnabled
}

func (r *Repository) RegisterSensor(ctx context.Context, s management.SensorRegistration) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	var site interface{}
	if s.SiteID != "" {
		if _, err := tx.ExecContext(ctx, `INSERT INTO sites(id,name) VALUES($1,$1) ON CONFLICT(id) DO NOTHING`, s.SiteID); err != nil {
			return err
		}
		site = s.SiteID
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO sensors(id,name,site_id,status,version,hostname,certificate_fingerprint,last_seen)
VALUES($1,$2,$3,'online',$4,$5,$6,NOW())
ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,site_id=EXCLUDED.site_id,version=EXCLUDED.version,hostname=EXCLUDED.hostname,certificate_fingerprint=EXCLUDED.certificate_fingerprint,last_seen=NOW(),status='online'`, s.ID, s.Name, site, s.Version, s.Hostname, s.CertificateFingerprint)
	if err != nil {
		return err
	}
	return tx.Commit()
}

// SetSensorAuthToken binds a cryptographically random bearer token to one
// sensor. Only its SHA-256 digest is persisted; the plaintext is returned once
// during enrollment and never becomes queryable through the API.
func (r *Repository) SetSensorAuthToken(ctx context.Context, sensorID, tokenHash string) error {
	result, err := r.db.ExecContext(ctx, `UPDATE sensors SET auth_token_hash=$2, auth_token_rotated_at=NOW() WHERE id=$1`, sensorID, tokenHash)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n != 1 {
		return ErrNotFound
	}
	return nil
}

func (r *Repository) SensorAuthTokenHash(ctx context.Context, sensorID string) (string, error) {
	var hash string
	err := r.db.QueryRowContext(ctx, `SELECT auth_token_hash FROM sensors WHERE id=$1`, sensorID).Scan(&hash)
	if errors.Is(err, sql.ErrNoRows) {
		return "", ErrNotFound
	}
	return hash, err
}

// RuleName looks up a rule's human-readable Name from a sensor's current
// reported rule list, for audit logging (an ID alone in the Audit log
// isn't very readable). Best-effort: returns ok=false if the sensor or
// rule isn't found — not an error condition, the caller falls back to
// showing the ID.
func (r *Repository) RuleName(ctx context.Context, sensorID, ruleID string) (name string, ok bool) {
	var rulesJSON []byte
	if err := r.db.QueryRowContext(ctx, `SELECT rules FROM sensor_telemetry WHERE sensor_id=$1`, sensorID).Scan(&rulesJSON); err != nil {
		return "", false
	}
	var rules []struct {
		ID   string `json:"id"`
		Name string `json:"name"`
	}
	if json.Unmarshal(rulesJSON, &rules) != nil {
		return "", false
	}
	for _, rule := range rules {
		if rule.ID == ruleID {
			return rule.Name, rule.Name != ""
		}
	}
	return "", false
}
func (r *Repository) Heartbeat(ctx context.Context, h management.Heartbeat) error {
	status := "online"
	if captureStatus := strings.ToLower(strings.TrimSpace(h.Health["capture"])); captureStatus == "running" || captureStatus == "stopped" {
		status = captureStatus
	}
	stringValue := func(values map[string]string, key string) string {
		if values == nil {
			return ""
		}
		return values[key]
	}
	interfaceValue := func(key string) interface{} {
		if h.Capture == nil {
			return nil
		}
		return h.Capture[key]
	}
	toString := func(value interface{}) string {
		if value == nil {
			return ""
		}
		return fmt.Sprint(value)
	}
	toInt32 := func(value interface{}) int32 {
		switch typed := value.(type) {
		case float64:
			return int32(typed)
		case int:
			return int32(typed)
		case int32:
			return typed
		case int64:
			return int32(typed)
		default:
			return 0
		}
	}
	toBool := func(value interface{}) bool {
		typed, ok := value.(bool)
		return ok && typed
	}
	_, err := r.db.ExecContext(ctx, `UPDATE sensors SET
 status=$4,version=$2,hostname=$3,go_version=$5,libpcap_version=$6,gopacket_version=$7,
 capture_backend=$8,capture_interface=$9,capture_snaplen=$10,capture_promiscuous=$11,last_seen=NOW(),last_heartbeat_at=NOW(),
 last_sync_attempt_at=NULLIF($12, '0001-01-01'::timestamptz),last_sync_success_at=NULLIF($13, '0001-01-01'::timestamptz),
 pending_records=$14::bigint,sync_failures=$15::integer,last_sync_error=$16,sync_sequence=$17,
 sync_status=CASE WHEN $15::integer>0 AND $14::bigint>0 THEN 'stalled' WHEN $15::integer>0 THEN 'error' WHEN $14::bigint>0 THEN 'pending' ELSE 'healthy' END
 WHERE id=$1`, h.SensorID, h.Version, h.Hostname, status,
		stringValue(h.Versions, "go"), stringValue(h.Versions, "libpcap"), stringValue(h.Versions, "gopacket"),
		toString(interfaceValue("backend")), toString(interfaceValue("interface")), toInt32(interfaceValue("snaplen")), toBool(interfaceValue("promiscuous")),
		h.Sync.LastAttemptAt, h.Sync.LastSuccessAt, h.Sync.PendingRecords, h.Sync.ConsecutiveFailures, h.Sync.LastError, h.Sync.Sequence)
	if err != nil {
		return err
	}
	healthJSON, _ := json.Marshal(h.Health)
	metricsJSON, _ := json.Marshal(h.Metrics)
	versionsJSON, _ := json.Marshal(h.Versions)
	captureJSON, _ := json.Marshal(h.Capture)
	syncJSON, _ := json.Marshal(h.Sync)
	_, err = r.db.ExecContext(ctx, `INSERT INTO sensor_metrics(sensor_id,recorded_at,uptime_seconds,health,metrics,versions,capture,sync) VALUES($1,NOW(),$2,$3,$4,$5,$6,$7)`, h.SensorID, h.Uptime, healthJSON, metricsJSON, versionsJSON, captureJSON, syncJSON)
	if err == nil {
		_, _ = r.db.ExecContext(ctx, `DELETE FROM sensor_metrics WHERE recorded_at < NOW() - INTERVAL '7 days'`)
	}
	return err
}
func healthFromSample(sample management.SensorMetricSample, lastSeen time.Time) (string, []string) {
	reasons := []string{}
	if time.Since(lastSeen) > 90*time.Second {
		return "offline", []string{"No recent heartbeat"}
	}
	number := func(path ...string) float64 {
		var current interface{} = sample.Metrics
		for _, key := range path {
			m, ok := current.(map[string]interface{})
			if !ok {
				return 0
			}
			current = m[key]
		}
		switch v := current.(type) {
		case float64:
			return v
		case int:
			return float64(v)
		case int64:
			return float64(v)
		}
		return 0
	}
	drops := number("capture", "drop_rate_percent")
	mem := number("system", "memory_percent")
	queue := number("pipeline", "event_queue_percent")
	if drops >= 5 {
		reasons = append(reasons, fmt.Sprintf("Packet drop rate %.1f%%", drops))
	}
	if mem >= 95 {
		reasons = append(reasons, fmt.Sprintf("Memory usage %.1f%%", mem))
	}
	if queue >= 95 {
		reasons = append(reasons, fmt.Sprintf("Event queue %.1f%% full", queue))
	}
	if sample.Sync.ConsecutiveFailures >= 3 {
		reasons = append(reasons, "Repeated Central synchronization failures")
	}
	if len(reasons) > 0 {
		return "critical", reasons
	}
	if drops >= 1 {
		reasons = append(reasons, fmt.Sprintf("Packet drop rate %.1f%%", drops))
	}
	if mem >= 80 {
		reasons = append(reasons, fmt.Sprintf("Memory usage %.1f%%", mem))
	}
	if queue >= 75 {
		reasons = append(reasons, fmt.Sprintf("Event queue %.1f%% full", queue))
	}
	if sample.Sync.ConsecutiveFailures > 0 {
		reasons = append(reasons, "Central synchronization degraded")
	}
	if len(reasons) > 0 {
		return "warning", reasons
	}
	return "healthy", nil
}

func (r *Repository) SensorMetricHistory(ctx context.Context, sensorID string, since time.Time, limit int) ([]management.SensorMetricSample, error) {
	if limit <= 0 || limit > 10000 {
		limit = 2000
	}
	rows, err := r.db.QueryContext(ctx, `SELECT sensor_id,recorded_at,uptime_seconds,health,metrics,versions,capture,sync FROM sensor_metrics WHERE sensor_id=$1 AND recorded_at >= $2 ORDER BY recorded_at ASC LIMIT $3`, sensorID, since, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []management.SensorMetricSample{}
	for rows.Next() {
		var x management.SensorMetricSample
		var health, metrics, versions, capture, sync []byte
		if err := rows.Scan(&x.SensorID, &x.RecordedAt, &x.UptimeSeconds, &health, &metrics, &versions, &capture, &sync); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(health, &x.Health)
		_ = json.Unmarshal(metrics, &x.Metrics)
		_ = json.Unmarshal(versions, &x.Versions)
		_ = json.Unmarshal(capture, &x.Capture)
		_ = json.Unmarshal(sync, &x.Sync)
		x.HealthState, x.HealthReasons = healthFromSample(x, x.RecordedAt)
		out = append(out, x)
	}
	return out, rows.Err()
}

func (r *Repository) LatestSensorMetrics(ctx context.Context) ([]management.SensorMetricSample, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT DISTINCT ON (m.sensor_id) m.sensor_id,m.recorded_at,m.uptime_seconds,m.health,m.metrics,m.versions,m.capture,m.sync,s.last_seen FROM sensor_metrics m JOIN sensors s ON s.id=m.sensor_id ORDER BY m.sensor_id,m.recorded_at DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []management.SensorMetricSample{}
	for rows.Next() {
		var x management.SensorMetricSample
		var health, metrics, versions, capture, sync []byte
		var lastSeen time.Time
		if err := rows.Scan(&x.SensorID, &x.RecordedAt, &x.UptimeSeconds, &health, &metrics, &versions, &capture, &sync, &lastSeen); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(health, &x.Health)
		_ = json.Unmarshal(metrics, &x.Metrics)
		_ = json.Unmarshal(versions, &x.Versions)
		_ = json.Unmarshal(capture, &x.Capture)
		_ = json.Unmarshal(sync, &x.Sync)
		x.HealthState, x.HealthReasons = healthFromSample(x, lastSeen)
		out = append(out, x)
	}
	return out, rows.Err()
}

func (r *Repository) SchemaVersion(ctx context.Context) int64 {
	var version int64
	if err := r.db.QueryRowContext(ctx, `SELECT COALESCE(MAX(version),0) FROM schema_migrations`).Scan(&version); err != nil {
		return 0
	}
	return version
}

func (r *Repository) ListSensors(ctx context.Context) ([]management.Sensor, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT id,name,COALESCE(site_id,''),status,version,hostname,last_seen,COALESCE(certificate_fingerprint,''),
COALESCE(go_version,''),COALESCE(libpcap_version,''),COALESCE(gopacket_version,''),COALESCE(capture_backend,''),
COALESCE(capture_interface,''),COALESCE(capture_snaplen,0),COALESCE(capture_promiscuous,FALSE),
last_heartbeat_at,last_sync_attempt_at,last_sync_success_at,last_data_received_at,COALESCE(sync_status,'unknown'),COALESCE(pending_records,0),COALESCE(sync_failures,0),COALESCE(last_sync_error,''),COALESCE(sync_sequence,0) FROM sensors ORDER BY name,id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []management.Sensor
	for rows.Next() {
		var s management.Sensor
		if err := rows.Scan(&s.ID, &s.Name, &s.SiteID, &s.Status, &s.Version, &s.Hostname, &s.LastSeen, &s.CertificateFingerprint,
			&s.GoVersion, &s.LibpcapVersion, &s.GopacketVersion, &s.CaptureBackend, &s.CaptureInterface, &s.CaptureSnaplen, &s.CapturePromiscuous, &s.LastHeartbeatAt, &s.LastSyncAttemptAt, &s.LastSyncSuccessAt, &s.LastDataReceivedAt, &s.SyncStatus, &s.PendingRecords, &s.SyncFailures, &s.LastSyncError, &s.SyncSequence); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}
func (r *Repository) PutRuleSet(ctx context.Context, rs management.RuleSet) error {
	data, err := json.Marshal(rs.Rules)
	if err != nil {
		return err
	}
	_, err = r.db.ExecContext(ctx, `INSERT INTO rule_sets(id,name,version,rules,updated_at) VALUES($1,$2,1,$3,NOW()) ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,version=rule_sets.version+1,rules=EXCLUDED.rules,updated_at=NOW()`, rs.ID, rs.Name, data)
	return err
}
func (r *Repository) GetRuleSet(ctx context.Context, id string) (*management.RuleSet, error) {
	var rs management.RuleSet
	var data []byte
	err := r.db.QueryRowContext(ctx, `SELECT id,name,version,rules,updated_at FROM rule_sets WHERE id=$1`, id).Scan(&rs.ID, &rs.Name, &rs.Version, &data, &rs.UpdatedAt)
	if err != nil {
		return nil, err
	}
	if err := json.Unmarshal(data, &rs.Rules); err != nil {
		return nil, err
	}
	return &rs, nil
}
func (r *Repository) AssignedRuleSet(ctx context.Context, sensorID string) (*management.RuleSet, error) {
	var id string
	err := r.db.QueryRowContext(ctx, `SELECT rule_set_id FROM sensor_rule_sets WHERE sensor_id=$1`, sensorID).Scan(&id)
	if err != nil {
		return nil, err
	}
	return r.GetRuleSet(ctx, id)
}
func (r *Repository) AssignRuleSet(ctx context.Context, sensorID, ruleSetID string) error {
	_, err := r.db.ExecContext(ctx, `INSERT INTO sensor_rule_sets(sensor_id,rule_set_id) VALUES($1,$2) ON CONFLICT(sensor_id) DO UPDATE SET rule_set_id=EXCLUDED.rule_set_id`, sensorID, ruleSetID)
	return err
}

// MarkOffline flips status to 'offline' for any sensor whose last_seen
// is older than olderThan — but only ones not already offline, and
// returns exactly those ids. Both matter for auditing this: without the
// status!='offline' guard, a sensor that's been down for days would get
// "marked offline" (and audited) again on every single sweep interval,
// not just the one time it actually went down.
func (r *Repository) MarkOffline(ctx context.Context, olderThan time.Duration) ([]string, error) {
	rows, err := r.db.QueryContext(ctx,
		`UPDATE sensors SET status='offline' WHERE status != 'offline' AND last_seen < NOW() - ($1 * INTERVAL '1 second') RETURNING id`,
		int64(olderThan/time.Second),
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return ids, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// DeleteSensor removes a sensor's row and, via ON DELETE CASCADE on
// every sensor-scoped table's foreign key, everything derived from it:
// telemetry, topology history, alert history, analysis jobs, rule
// assignments, and pending commands. This is NOT a permanent ban on the
// sensor id — if that sensor is still running, its very next
// register()/heartbeat() upsert just recreates the row from scratch
// (with fresh, empty history), since those are ON CONFLICT DO UPDATE.
func (r *Repository) DeleteSensor(ctx context.Context, id string) error {
	_, err := r.db.ExecContext(ctx, `DELETE FROM sensors WHERE id=$1`, id)
	return err
}

func (r *Repository) PutTelemetry(ctx context.Context, x management.TelemetrySnapshot) ([]AlertHistoryEntry, error) {
	if x.CapturedAt.IsZero() {
		x.CapturedAt = time.Now().UTC()
	}
	defaults := func(v json.RawMessage, fallback string) json.RawMessage {
		if len(v) == 0 {
			return json.RawMessage(fallback)
		}
		return v
	}
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(ctx, `INSERT INTO sensor_telemetry(sensor_id,captured_at,topology,tags,tag_changes,tag_events,alerts,baseline,rules,dns_observations,smb_observations,batch_id,sequence,checksum,updated_at)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,NOW()) ON CONFLICT(sensor_id) DO UPDATE SET captured_at=EXCLUDED.captured_at,topology=EXCLUDED.topology,tags=EXCLUDED.tags,tag_changes=EXCLUDED.tag_changes,tag_events=EXCLUDED.tag_events,alerts=EXCLUDED.alerts,baseline=EXCLUDED.baseline,rules=EXCLUDED.rules,dns_observations=EXCLUDED.dns_observations,smb_observations=EXCLUDED.smb_observations,batch_id=EXCLUDED.batch_id,sequence=EXCLUDED.sequence,checksum=EXCLUDED.checksum,updated_at=NOW()
WHERE sensor_telemetry.sequence <= EXCLUDED.sequence`, x.SensorID, x.CapturedAt, x.Topology, x.Tags, defaults(x.TagChanges, "[]"), defaults(x.TagEvents, "[]"), defaults(x.Alerts, "[]"), defaults(x.Baseline, "{}"), defaults(x.Rules, "[]"), defaults(x.DNSObservations, "[]"), defaults(x.SMBObservations, "[]"), x.BatchID, x.Sequence, x.Checksum)
	if err != nil {
		return nil, err
	}
	var alerts []map[string]interface{}
	if r.siemAlertsEnabled && len(x.Alerts) > 0 && json.Unmarshal(x.Alerts, &alerts) == nil {
		for _, alert := range alerts {
			id := firstString(alert, "ID", "id")
			if id == "" {
				continue
			}
			count := fmt.Sprint(firstValue(alert, "Count", "count"))
			lastSeen := fmt.Sprint(firstValue(alert, "LastSeen", "last_seen"))
			status := fmt.Sprint(firstValue(alert, "Status", "status"))
			eventKey := fmt.Sprintf("alert:%s:%s:%s:%s:%s", x.SensorID, id, count, lastSeen, status)
			envelope := map[string]interface{}{
				"source":     "otlens-central",
				"kind":       "alert",
				"event_time": x.CapturedAt,
				"sensor_id":  x.SensorID,
				"alert":      alert,
			}
			payload, marshalErr := json.Marshal(envelope)
			if marshalErr != nil {
				return nil, marshalErr
			}
			if _, err = tx.ExecContext(ctx, `INSERT INTO siem_outbox(event_key,kind,payload) VALUES($1,'alert',$2) ON CONFLICT(event_key) DO NOTHING`, eventKey, payload); err != nil {
				return nil, err
			}
		}
	}
	if _, err = tx.ExecContext(ctx, `UPDATE sensors SET last_data_received_at=NOW(),last_sync_success_at=NOW(),sync_status='healthy',pending_records=0,sync_failures=0,last_sync_error='',sync_sequence=GREATEST(sync_sequence,$2) WHERE id=$1`, x.SensorID, x.Sequence); err != nil {
		return nil, err
	}
	// Fold this sync's nodes/edges into the durable per-sensor ledgers
	// (see topology_edges.go) before committing, so it's atomic with the
	// rest of the sync — a failed upsert here rolls back the whole
	// telemetry write rather than silently skipping just the topology
	// history. Nodes must go in before edges are read back out by
	// buildTopologyResponse matters less here (both land in this same
	// transaction), but nodes are upserted first on principle: an edge
	// whose endpoint isn't in the node ledger yet is still fine to have
	// on record, since ListTopologyNodes is a superset fill-in, not a
	// strict foreign key.
	var graph topology.Graph
	if len(x.Topology) > 0 && json.Unmarshal(x.Topology, &graph) == nil {
		if err := persistFlowObservations(ctx, tx, x.SensorID, x.CapturedAt, graph.Edges); err != nil {
			return nil, err
		}
		if err := upsertTopologyNodes(ctx, tx, x.SensorID, graph.Nodes); err != nil {
			return nil, err
		}
		if err := upsertTopologyEdges(ctx, tx, x.SensorID, aggregateEdges(graph.Edges)); err != nil {
			return nil, err
		}
	}
	if err := persistDNSObservations(ctx, tx, x.SensorID, x.DNSObservations); err != nil {
		return nil, err
	}
	if err := persistSMBObservations(ctx, tx, x.SensorID, x.SMBObservations); err != nil {
		return nil, err
	}
	newAlerts, err := upsertAlertHistory(ctx, tx, x.SensorID, x.Alerts)
	if err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return newAlerts, nil
}

func firstValue(m map[string]interface{}, keys ...string) interface{} {
	for _, key := range keys {
		if v, ok := m[key]; ok {
			return v
		}
	}
	return ""
}

func firstString(m map[string]interface{}, keys ...string) string {
	return fmt.Sprint(firstValue(m, keys...))
}

func (r *Repository) Telemetry(ctx context.Context) ([]management.TelemetrySnapshot, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT sensor_id,captured_at,topology,tags,tag_changes,tag_events,alerts,baseline,rules,dns_observations,smb_observations,batch_id,sequence,checksum FROM sensor_telemetry ORDER BY sensor_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []management.TelemetrySnapshot
	for rows.Next() {
		var x management.TelemetrySnapshot
		if err := rows.Scan(&x.SensorID, &x.CapturedAt, &x.Topology, &x.Tags, &x.TagChanges, &x.TagEvents, &x.Alerts, &x.Baseline, &x.Rules, &x.DNSObservations, &x.SMBObservations, &x.BatchID, &x.Sequence, &x.Checksum); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}

// TelemetryFingerprint returns each sensor's current telemetry sequence
// number without touching any of the (potentially large) JSONB columns.
// Handlers that serve a derived/aggregated view — like /topology — use
// this to cheaply detect "nothing changed since last time" before paying
// for a full topology fetch + JSON decode. Ordered by sensor_id so the
// result is stable and directly hashable.
func (r *Repository) TelemetryFingerprint(ctx context.Context) (map[string]int64, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT sensor_id, sequence FROM sensor_telemetry ORDER BY sensor_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[string]int64)
	for rows.Next() {
		var id string
		var seq int64
		if err := rows.Scan(&id, &seq); err != nil {
			return nil, err
		}
		out[id] = seq
	}
	return out, rows.Err()
}

// TopologyRow is the minimal per-sensor payload the /topology handler
// needs: just enough to rebuild the aggregated graph, without pulling the
// tags/alerts/baseline/rules columns that other endpoints care about.
type TopologyRow struct {
	SensorID string
	Topology json.RawMessage
}

func (r *Repository) TelemetryTopology(ctx context.Context) ([]TopologyRow, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT sensor_id, topology FROM sensor_telemetry ORDER BY sensor_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TopologyRow
	for rows.Next() {
		var x TopologyRow
		if err := rows.Scan(&x.SensorID, &x.Topology); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}

func (r *Repository) QueueCommands(ctx context.Context, sensorID, typ string, targets []string) error {
	clean := make([]string, 0, len(targets))
	for _, t := range targets {
		if t != "" {
			clean = append(clean, t)
		}
	}
	if len(clean) == 0 {
		return nil
	}
	// One round trip regardless of how many targets — unnest() expands
	// the array into rows server-side. The naive "one INSERT per target"
	// loop this replaced took whole seconds-to-minutes (visible as "did
	// this even do anything?" in the UI) once someone selected a
	// realistic bulk-action count (thousands of alerts, say), since each
	// row was its own network round trip to Postgres.
	_, err := r.db.ExecContext(ctx,
		`INSERT INTO sensor_commands(sensor_id,command_type,target) SELECT $1, $2, unnest($3::text[])`,
		sensorID, typ, clean,
	)
	return err
}
func (r *Repository) PopCommands(ctx context.Context, sensorID string) ([]management.Command, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	rows, err := tx.QueryContext(ctx, `SELECT id,command_type,target FROM sensor_commands WHERE sensor_id=$1 AND delivered_at IS NULL ORDER BY id FOR UPDATE`, sensorID)
	if err != nil {
		return nil, err
	}
	var out []management.Command
	var ids []int64
	for rows.Next() {
		var c management.Command
		if err = rows.Scan(&c.ID, &c.Type, &c.Target); err != nil {
			rows.Close()
			return nil, err
		}
		out = append(out, c)
		ids = append(ids, c.ID)
	}
	rows.Close()
	if len(ids) > 0 {
		if _, err = tx.ExecContext(ctx, `UPDATE sensor_commands SET delivered_at=NOW() WHERE id = ANY($1)`, ids); err != nil {
			return nil, err
		}
		for _, command := range out {
			if command.Type != "recon.safe_discovery" {
				continue
			}
			var payload struct {
				JobID string `json:"job_id"`
			}
			if json.Unmarshal([]byte(command.Target), &payload) == nil && payload.JobID != "" {
				if _, err = tx.ExecContext(ctx, `UPDATE reconnaissance_jobs SET status='running',started_at=COALESCE(started_at,NOW()) WHERE id=$1 AND status='queued'`, payload.JobID); err != nil {
					return nil, err
				}
			}
		}
	}
	if err = tx.Commit(); err != nil {
		return nil, err
	}
	return out, nil
}

type SIEMOutboxEvent struct {
	ID       int64
	Kind     string
	Payload  json.RawMessage
	Attempts int
}

func (r *Repository) EnqueueSIEM(ctx context.Context, eventKey, kind string, payload interface{}) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	_, err = r.db.ExecContext(ctx, `INSERT INTO siem_outbox(event_key,kind,payload) VALUES($1,$2,$3) ON CONFLICT(event_key) DO NOTHING`, eventKey, kind, data)
	return err
}

func (r *Repository) PendingSIEM(ctx context.Context, limit, maxAttempts int) ([]SIEMOutboxEvent, error) {
	if limit <= 0 {
		limit = 100
	}
	query := `SELECT id,kind,payload,attempts FROM siem_outbox WHERE delivered_at IS NULL AND next_attempt_at <= NOW()`
	args := []interface{}{}
	if maxAttempts > 0 {
		query += ` AND attempts < $1`
		args = append(args, maxAttempts)
	}
	query += ` ORDER BY id LIMIT $` + fmt.Sprint(len(args)+1)
	args = append(args, limit)
	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []SIEMOutboxEvent
	for rows.Next() {
		var e SIEMOutboxEvent
		if err := rows.Scan(&e.ID, &e.Kind, &e.Payload, &e.Attempts); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

func (r *Repository) MarkSIEMDelivered(ctx context.Context, id int64) error {
	_, err := r.db.ExecContext(ctx, `UPDATE siem_outbox SET delivered_at=NOW(),last_error='' WHERE id=$1`, id)
	return err
}

func (r *Repository) MarkSIEMFailed(ctx context.Context, id int64, retryAfter time.Duration, message string) error {
	if retryAfter <= 0 {
		retryAfter = 15 * time.Second
	}
	_, err := r.db.ExecContext(ctx, `UPDATE siem_outbox SET attempts=attempts+1,last_error=$2,next_attempt_at=NOW()+($3*INTERVAL '1 second') WHERE id=$1`, id, message, int64(retryAfter/time.Second))
	return err
}

func (r *Repository) CreateAnalysisJob(ctx context.Context, job management.AnalysisJob, storedPath string) error {
	protocols, _ := json.Marshal(job.Protocols)
	_, err := r.db.ExecContext(ctx, `INSERT INTO analysis_jobs(id,sensor_id,filename,stored_path,sha256,size_bytes,status,protocols) VALUES($1,$2,$3,$4,$5,$6,'queued',$7)`, job.ID, job.SensorID, job.Filename, storedPath, job.SHA256, job.SizeBytes, protocols)
	return err
}

func (r *Repository) ListAnalysisJobs(ctx context.Context) ([]management.AnalysisJob, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT id,sensor_id,filename,sha256,size_bytes,status,protocols,packets,assets_discovered,flows_discovered,tags_discovered,alerts_generated,error,created_at,started_at,completed_at,result FROM analysis_jobs ORDER BY created_at DESC LIMIT 200`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []management.AnalysisJob{}
	for rows.Next() {
		var j management.AnalysisJob
		var protocols, result []byte
		if err := rows.Scan(&j.ID, &j.SensorID, &j.Filename, &j.SHA256, &j.SizeBytes, &j.Status, &protocols, &j.Packets, &j.AssetsDiscovered, &j.FlowsDiscovered, &j.TagsDiscovered, &j.AlertsGenerated, &j.Error, &j.CreatedAt, &j.StartedAt, &j.CompletedAt, &result); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(protocols, &j.Protocols)
		j.Result = result
		out = append(out, j)
	}
	return out, rows.Err()
}

func (r *Repository) ClaimAnalysisJob(ctx context.Context, sensorID string) (*management.AnalysisJob, string, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, "", err
	}
	defer tx.Rollback()
	var j management.AnalysisJob
	var protocols []byte
	var path string
	err = tx.QueryRowContext(ctx, `SELECT id,sensor_id,filename,stored_path,sha256,size_bytes,protocols,created_at FROM analysis_jobs WHERE sensor_id=$1 AND status='queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1`, sensorID).Scan(&j.ID, &j.SensorID, &j.Filename, &path, &j.SHA256, &j.SizeBytes, &protocols, &j.CreatedAt)
	if err != nil {
		return nil, "", err
	}
	_ = json.Unmarshal(protocols, &j.Protocols)
	now := time.Now().UTC()
	j.Status = "running"
	j.StartedAt = &now
	if _, err = tx.ExecContext(ctx, `UPDATE analysis_jobs SET status='running',started_at=NOW() WHERE id=$1`, j.ID); err != nil {
		return nil, "", err
	}
	if err = tx.Commit(); err != nil {
		return nil, "", err
	}
	return &j, path, nil
}

func (r *Repository) AnalysisJobPath(ctx context.Context, id, sensorID string) (string, string, error) {
	var path, name string
	err := r.db.QueryRowContext(ctx, `SELECT stored_path,filename FROM analysis_jobs WHERE id=$1 AND sensor_id=$2`, id, sensorID).Scan(&path, &name)
	return path, name, err
}

func (r *Repository) FinishAnalysisJob(ctx context.Context, id, sensorID string, result management.AnalysisResult) error {
	status := "completed"
	if result.Error != "" {
		status = "failed"
	}
	data, _ := json.Marshal(result)
	_, err := r.db.ExecContext(ctx, `UPDATE analysis_jobs SET status=$3,packets=$4,assets_discovered=$5,flows_discovered=$6,tags_discovered=$7,alerts_generated=$8,result=$9,error=$10,completed_at=NOW() WHERE id=$1 AND sensor_id=$2`, id, sensorID, status, result.Packets, result.AssetsDiscovered, result.FlowsDiscovered, result.TagsDiscovered, result.AlertsGenerated, data, result.Error)
	return err
}

func (r *Repository) DeleteAnalysisJob(ctx context.Context, id string) (string, error) {
	var path string
	err := r.db.QueryRowContext(ctx, `DELETE FROM analysis_jobs WHERE id=$1 RETURNING stored_path`, id).Scan(&path)
	return path, err
}

type BackupRecord struct {
	ID        string    `json:"id"`
	Kind      string    `json:"kind"`
	Name      string    `json:"name"`
	SizeBytes int64     `json:"size_bytes"`
	SHA256    string    `json:"sha256"`
	CreatedAt time.Time `json:"created_at"`
}

func (r *Repository) ResetCentral(ctx context.Context, operation string) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	switch operation {
	case "telemetry", "database":
		// Telemetry reset must never remove configuration, rules, sensors,
		// sites, pending management commands, SIEM data or backups.
		// topology_edges/topology_nodes are included even though they're
		// separate tables from sensor_telemetry — they're durable
		// derived-from-telemetry history (see topology_edges.go), so a
		// telemetry reset that left them alone would make the Topology
		// tab keep showing everything exactly as before, which is
		// confusing when the whole point was to clear things out. Note
		// this only clears Central's copy: each sensor still has its own
		// local state and will re-report it on its next sync unless that
		// sensor is also reset (Sensors tab / Data Management's sensor
		// reset operations).
		_, err = tx.ExecContext(ctx, `TRUNCATE sensor_telemetry, topology_edges, topology_nodes, asset_risk, asset_risk_history RESTART IDENTITY`)
	case "alerts":
		_, err = tx.ExecContext(ctx, `UPDATE sensor_telemetry SET alerts='[]'::jsonb, updated_at=NOW()`)
	case "incidents":
		// Clear both correlated investigation records and malware/contact-tracing incidents.
		_, err = tx.ExecContext(ctx, `TRUNCATE incident_comments, incident_events, incidents, alert_history, malware_incidents RESTART IDENTITY CASCADE`)
	case "siem":
		_, err = tx.ExecContext(ctx, `TRUNCATE siem_outbox RESTART IDENTITY`)
	case "analysis":
		_, err = tx.ExecContext(ctx, `TRUNCATE analysis_jobs RESTART IDENTITY`)
	case "rules":
		// Central rule assignments are configuration. This explicit reset is
		// intentionally separate from telemetry/database reset.
		_, err = tx.ExecContext(ctx, `TRUNCATE sensor_rule_sets, rule_sets CASCADE`)
	case "factory":
		// Preserve the sensor registry and sensor_commands long enough for
		// connected sensors to receive sensor.factory.reset. Deleting those
		// rows here made the reset command disappear before the next sync and
		// the sensor immediately uploaded all old telemetry again.
		_, err = tx.ExecContext(ctx, `TRUNCATE sensor_telemetry, topology_edges, topology_nodes, analysis_jobs, siem_outbox, sensor_rule_sets, rule_sets RESTART IDENTITY CASCADE`)
	default:
		return fmt.Errorf("unsupported central reset operation %q", operation)
	}
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (r *Repository) CreateCentralBackup(ctx context.Context, id, name string) (BackupRecord, error) {
	payload := map[string]json.RawMessage{}
	queries := map[string]string{
		"sites":            `SELECT COALESCE(jsonb_agg(t),'[]'::jsonb) FROM (SELECT * FROM sites ORDER BY id) t`,
		"sensors":          `SELECT COALESCE(jsonb_agg(t),'[]'::jsonb) FROM (SELECT * FROM sensors ORDER BY id) t`,
		"rule_sets":        `SELECT COALESCE(jsonb_agg(t),'[]'::jsonb) FROM (SELECT * FROM rule_sets ORDER BY id) t`,
		"sensor_rule_sets": `SELECT COALESCE(jsonb_agg(t),'[]'::jsonb) FROM (SELECT * FROM sensor_rule_sets ORDER BY sensor_id) t`,
		"sensor_telemetry": `SELECT COALESCE(jsonb_agg(t),'[]'::jsonb) FROM (SELECT * FROM sensor_telemetry ORDER BY sensor_id) t`,
	}
	for key, q := range queries {
		var raw []byte
		if err := r.db.QueryRowContext(ctx, q).Scan(&raw); err != nil {
			return BackupRecord{}, err
		}
		payload[key] = raw
	}
	data, err := json.Marshal(payload)
	if err != nil {
		return BackupRecord{}, err
	}
	sum := fmt.Sprintf("%x", sha256.Sum256(data))
	if name == "" {
		name = "central-" + time.Now().UTC().Format("20060102-150405")
	}
	_, err = r.db.ExecContext(ctx, `INSERT INTO system_backups(id,kind,name,payload,size_bytes,sha256) VALUES($1,'central',$2,$3,$4,$5)`, id, name, data, len(data), sum)
	if err != nil {
		return BackupRecord{}, err
	}
	return BackupRecord{ID: id, Kind: "central", Name: name, SizeBytes: int64(len(data)), SHA256: sum, CreatedAt: time.Now().UTC()}, nil
}

func (r *Repository) ListBackups(ctx context.Context) ([]BackupRecord, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT id,kind,name,size_bytes,sha256,created_at FROM system_backups ORDER BY created_at DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []BackupRecord
	for rows.Next() {
		var b BackupRecord
		if err := rows.Scan(&b.ID, &b.Kind, &b.Name, &b.SizeBytes, &b.SHA256, &b.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, b)
	}
	return out, rows.Err()
}
func (r *Repository) DeleteBackup(ctx context.Context, id string) error {
	_, err := r.db.ExecContext(ctx, `DELETE FROM system_backups WHERE id=$1`, id)
	return err
}
func (r *Repository) BackupPayload(ctx context.Context, id string) ([]byte, string, error) {
	var b []byte
	var name string
	err := r.db.QueryRowContext(ctx, `SELECT payload,name FROM system_backups WHERE id=$1`, id).Scan(&b, &name)
	return b, name, err
}
