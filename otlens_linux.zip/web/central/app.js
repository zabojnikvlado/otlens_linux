/*
 * OTLens Central UI bootstrap marker.
 *
 * The application is intentionally split into ordered classic-script modules
 * so existing shared state and event handlers remain backward compatible
 * without introducing a bundler:
 *   app-core.js       shared state, API, live connection and refresh primitives
 *   app-topology.js   topology and network visualization
 *   app-inventory.js  assets, devices, vulnerabilities and OT tags
 *   app-detection.js  alerts, incidents, rules and threat intelligence
 *   app-operations.js dashboard, audit, health, data and runtime operations
 *   app-admin.js      users, roles, settings, navigation and feature bootstrap
 */
console.info('OTLens Central UI modules loaded');
